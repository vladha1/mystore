export const products = [
  {
    id: 1,
    name: 'Chola Bhatura',
    price: 799,
    description: 'Fried flat bread with chickpey curry'
  },
  {
    id: 2,
    name: 'Samosa Chat',
    price: 699,
    description: 'Deep Fried patties with spicy potato filling, servved with Yogurt and condiments'
  },
  {
    id: 3,
    name: 'Alu tikki Chat',
    price: 299,
    description: 'Potato Cutlets, shallow fried on a hot cast iron plate. Served with  sweet and sour tamerind sauce'
  }
];


/*
Copyright Google LLC. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at https://angular.io/license
*/